function boost() {
alert("Optimizing system... ⚡");
}