const fill = document.querySelector(".fill");

let progress = 0;

const interval = setInterval(() => {
progress += 2;
fill.style.width = progress + "%";

if (progress >= 100) {
clearInterval(interval);
}
}, 60);