const { app, BrowserWindow } = require("electron");
const path = require("path");

let win;

function createWindow() {
win = new BrowserWindow({
width: 1000,
height: 650,
frame: false,
webPreferences: {
preload: path.join(__dirname, "preload.js"),
contextIsolation: true
}
});

// Load boot screen first
win.loadFile("renderer/boot.html");

// Switch to main app after boot animation
setTimeout(() => {
win.loadFile("renderer/app.html");
}, 4000);
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
if (process.platform !== "darwin") app.quit();
});